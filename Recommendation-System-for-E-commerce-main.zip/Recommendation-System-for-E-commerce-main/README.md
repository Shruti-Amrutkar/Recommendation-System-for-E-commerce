# E-commerce-recommender-system
A Data Science based E-commerce Recommender System using the ResNET50.

Modul used
1) DL-CNN
2) Transfer Learning(Resnet)
ResNET --> imageNet

        Plan of Attack
1) Import Model
   conventional neural network 
   ResNet Trained

2) Extract features
3) Export features
4) Generate Recommendation
  
  
![WhatsApp Image 2022-04-05 at 12 44 13 AM](https://user-images.githubusercontent.com/75496066/161722766-6b7c0dd5-1634-4e62-b27d-1e32ee53f001.jpeg)

![WhatsApp Image 2022-04-05 at 12 47 30 AM](https://user-images.githubusercontent.com/75496066/161722761-81e5f9cc-e9c4-45e5-8d33-4cb78db6f10b.jpeg)

![WhatsApp Image 2022-04-05 at 12 51 31 AM](https://user-images.githubusercontent.com/75496066/161722747-1d5fff1f-7f66-49e9-a1e7-242cd28445b6.jpeg)
